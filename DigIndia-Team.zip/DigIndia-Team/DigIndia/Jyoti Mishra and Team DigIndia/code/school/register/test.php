<?php
session_start();
echo $_SESSION['name'];
echo $_SESSION['id'];
echo $_SESSION['pass'];
echo $_SESSION['addr'];
echo $_SESSION['email'];
echo $_SESSION['ph'];
?>