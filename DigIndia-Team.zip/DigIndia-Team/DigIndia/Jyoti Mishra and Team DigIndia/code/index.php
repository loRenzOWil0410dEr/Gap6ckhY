<?php
header('Location: school/index.php');
?>